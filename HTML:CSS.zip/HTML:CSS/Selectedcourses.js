window.onload = setup
function setup(){
   let buttons = document.querySelectorAll(".but"); // locates which button to use
  
    buttons.forEach(btn=>{})
   for(let i=0; i<buttons.length; i++){
     buttons[i].addEventListener("click", addItem);  // This makes the website wait for the user to click on a button for a recation to occur
   }
 }
 
 
 let addedItems = []; // Links the button pressed and send the favorite class to the list
 let BestClass = [];  // This is the list of my favorite classes
  function addItem(e){
     let item = "content" +e.target.id;
       // This gets the id of the button which has a fail safe of an IF and ELSE statment after
    
   
  
  if (!BestClass.includes(item)){ // Makes sure the class has been added the list
    BestClass.push(item);
       var aside = document.querySelector("aside"); // This (aside) helps the program locate where to put the favorite class
       var firstselection = document.getElementById(item).innerHTML; //Finds the displayed content 
       var secondselection = aside.innerHTML; //This puts in a second favorite selection of a course
       aside.innerHTML = firstselection + secondselection ; //Makes sure the first selection of and the second selection are in the list (failsafe)
  }
 
 
   else{
     alert("Course already in Favorite Courses.");  // a alert with a button should pop up in the top center of the page. user must click ok 
    
}

  }